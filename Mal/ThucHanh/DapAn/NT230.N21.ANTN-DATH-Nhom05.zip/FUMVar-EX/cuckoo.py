import os
from pyvirtualdisplay import Display
from multiprocessing import Pool, Process
import subprocess as sp
import time

# sudo iptables -t nat -A POSTROUTING -o eth33 -s 192.168.56.0/24 -j MASQUERADE
# sudo iptables -P FORWARD DROP
# sudo iptables -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT
# sudo iptables -A FORWARD -s 192.168.56.0/24 -j ACCEPT

def create_hostonly_net():
    # os.system("sudo iptables -t nat -A POSTROUTING -o ens33 -s 192.168.56.0/24 -j MASQUERADE")
    # os.system("sudo iptables -A FORWARD -o ens33 -i vboxnet0 -s 192.168.56.0/24 -m conntrack --ctstate NEW -j ACCEPT")
    # os.system("sudo iptables -A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT")
    # os.system("sudo iptables -A POSTROUTING -t nat -j MASQUERADE")
    # os.system("sudo sysctl -w net.ipv4.ip_forward=1")
    os.system("VBoxManage hostonlyif create")
    os.system("VBoxManage hostonlyif ipconfig vboxnet0 --ip 192.168.56.1")
    os.system("sudo iptables -t nat -A POSTROUTING -o eth33 -s 192.168.56.0/24 -j MASQUERADE")
    os.system("sudo iptables -P FORWARD DROP")
    os.system("sudo iptables -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT")
    os.system("sudo iptables -A FORWARD -s 192.168.56.0/24 -j ACCEPT")

def virtualbox():
    disp = Display().start()
    os.system("sudo virtualbox")

def cuckoo_rooter():
    os.system("/home/cuckoo/cuckoo/bin/cuckoo rooter --sudo --group cuckoo")

def cuckoo_run():
    os.system("su cuckoo; . /home/cuckoo/cuckoo/bin/activate; cuckoo")

def cuckoo_api():
    os.system("su cuckoo; . /home/cuckoo/cuckoo/bin/activate; cuckoo api")

def cuckoo_web():
    os.system("su cuckoo; . /home/cuckoo/cuckoo/bin/activate; cuckoo web --host localhost --port 8080")


if __name__ == "__main__":
    network_list = sp.check_output(["ifconfig"])
    if "vboxnet0" not in network_list.decode("ascii"):
        create_hostonly_net()

    # p1 = Process(target=cuckoo_rooter, args=())
    # p2 = Process(target=cuckoo_run, args=())
    # p3 = Process(target=cuckoo_api, args=())
    # #p4 = Process(target=cuckoo_web, args=())
    # p1.start()
    # p2.start()
    # p3.start()
    # #p4.start()
    # p1.join()
    # p2.join()
    # p3.join()
    # p4.join()
