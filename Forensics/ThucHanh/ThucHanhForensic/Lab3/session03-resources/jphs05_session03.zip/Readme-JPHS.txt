These programs are available for test purposes only.

Please send me any useful comments for improvements.
In particular if you discover ways to detect the presence of the hidden
data (even if you can't extract it) I would like to hear about it. This
excludes the case where both the original and the modified jpeg are
available (in which case it is a trivial task!)

Remember they are FREE and BETA test versions. They may not work as
you expect. I offer no warranty and accept to liability for their use.

They are incompatible with earlier versions of similar products I have
written.

JPHIDE.EXE is a DOS program to hide a data file in a jpeg file.
JPSEEK.EXE is a DOS program to recover a file hidden with JPHIDE.EXE

JPHSWIN.EXE is a Windows-95 program which performs the same functions as
the two programs above.

The programs are free standing and require no special installation.

Allan Latham <alatham@flexsys-group.com> 7th January 1999.
